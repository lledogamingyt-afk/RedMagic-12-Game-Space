package com.example.redmagicstyle

import android.app.Activity
import android.app.AlertDialog
import android.app.usage.UsageStatsManager
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.LayerDrawable
import android.net.TrafficStats
import android.os.*
import android.provider.Settings
import android.media.projection.MediaProjectionManager
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.*
import java.io.File
import java.text.DecimalFormat

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("game_space", MODE_PRIVATE) }
    private val red = Color.rgb(255, 30, 50)
    private val dark = Color.rgb(8, 10, 16)
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var appList: LinearLayout
    private lateinit var search: EditText
    private var installedApps: List<ApplicationInfo> = emptyList()
    private var selectedMode = "BALANCE"
    private var previewWallpaperType = "turbine"
    private var previewWallpaperUri: String? = null
    private var previewWallpaperDim = 42
    private val handler = Handler(Looper.getMainLooper())
    private var lastRx = TrafficStats.getTotalRxBytes()
    private var lastTx = TrafficStats.getTotalTxBytes()
    private val number = DecimalFormat("0.0")

    companion object { private const val REQUEST_WALLPAPER = 41; private const val REQUEST_CAPTURE = 42 }

    private val telemetryTask = object : Runnable {
        override fun run() {
            if (::status.isInitialized) status.text = telemetryLine()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        selectedMode = prefs.getString("mode", "BALANCE") ?: "BALANCE"
        showHub()
        handler.post(telemetryTask)
    }

    override fun onDestroy() {
        handler.removeCallbacks(telemetryTask)
        super.onDestroy()
    }

    private fun label(value: String, size: Float = 14f, color: Int = Color.WHITE, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            letterSpacing = if (bold) 0.075f else 0.015f
            if (bold) typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
            setPadding(9, 7, 9, 7)
        }

    private fun button(value: String, action: () -> Unit): Button = Button(this).apply {
        text = value; isAllCaps = false; textSize = 12f; setTextColor(Color.WHITE)
        typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(Color.rgb(30, 33, 44)); cornerRadius = 13f; setStroke(2, red)
        }
        setOnClickListener { action() }
    }

    private fun showHub() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(14, 8, 14, 8); setBackgroundColor(dark)
        }
        applySavedWallpaper()
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val emblem = ImageView(this).apply {
            setImageResource(R.drawable.redmagic_emblem); scaleType = ImageView.ScaleType.FIT_CENTER
        }
        header.addView(emblem, LinearLayout.LayoutParams(48, 54))
        header.addView(label("REDMAGIC  GAME SPACE", 23f, red, true), LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(label("GALAXY A50  /  ANDROID", 10f, Color.LTGRAY, true))
        root.addView(header)
        status = label(telemetryLine(), 11f, Color.LTGRAY)
        root.addView(status)

        val modeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("ECO", "BALANCE", "RISE", "DIABLO").forEach { mode ->
            modeRow.addView(button(mode) { setMode(mode) }, LinearLayout.LayoutParams(0, 48, 1f).apply { setMargins(3, 2, 3, 2) })
        }
        root.addView(modeRow)

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(button("ADD GAME / APP") { showAppPicker() }, LinearLayout.LayoutParams(0, 46, 1f))
        actions.addView(button("PLUGINS") { showPlugins() }, LinearLayout.LayoutParams(0, 46, 1f))
        actions.addView(button("WALLPAPER") { chooseWallpaper() }, LinearLayout.LayoutParams(0, 46, 1f))
        actions.addView(button("SETTINGS") { showSettings() }, LinearLayout.LayoutParams(0, 46, 1f))
        root.addView(actions)

        val overlayRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        overlayRow.addView(button("ENABLE ENERGY CUBE") { enableOverlay() }, LinearLayout.LayoutParams(0, 46, 1f))
        overlayRow.addView(button("START LIVE SCREEN FPS") { requestFpsPermission() }, LinearLayout.LayoutParams(0, 46, 1f))
        overlayRow.addView(button("? GESTURE GUIDE") { showGuide() }, LinearLayout.LayoutParams(0, 46, 1f))
        root.addView(overlayRow)

        root.addView(label("INSTALLED GAMES & APPS", 16f, red, true))
        search = EditText(this).apply {
            hint = "Search installed games and apps"; setSingleLine(true); textSize = 13f
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            setPadding(12, 2, 12, 2)
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.rgb(24, 26, 35)); cornerRadius = 10f; setStroke(1, Color.DKGRAY)
            }
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { renderApps(s?.toString().orEmpty()) }
                override fun afterTextChanged(s: android.text.Editable?) {}
            })
        }
        root.addView(search, LinearLayout.LayoutParams(-1, 42))
        val scroll = ScrollView(this)
        appList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(appList)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        scanApps()
    }

    private fun wallpaperResource(type: String): Int = when (type) {
        "turbine" -> R.drawable.wallpaper_redmagic_turbine
        "blue" -> R.drawable.wallpaper_blue_velocity
        "violet" -> R.drawable.wallpaper_violet_grid
        "obsidian" -> R.drawable.wallpaper_obsidian_shards
        "cyan" -> R.drawable.wallpaper_cyan_pulse
        else -> R.drawable.wallpaper_crimson_circuit
    }

    private fun decodeGalleryWallpaper(uriText: String): android.graphics.Bitmap? {
        return try {
            val uri = android.net.Uri.parse(uriText)
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
            var sample = 1
            while (bounds.outWidth / sample > 1920 || bounds.outHeight / sample > 1920) sample *= 2
            val options = BitmapFactory.Options().apply { inSampleSize = sample }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
        } catch (_: Exception) { null }
    }

    private fun wallpaperDrawable(type: String, uriText: String?): android.graphics.drawable.Drawable? {
        val bitmap = if (type == "gallery" && !uriText.isNullOrBlank()) {
            decodeGalleryWallpaper(uriText)
        } else {
            try { BitmapFactory.decodeResource(resources, wallpaperResource(type)) } catch (_: Exception) { null }
        }
        return bitmap?.let { BitmapDrawable(resources, it) }
    }

    private fun dimColor(percent: Int): Int = Color.argb(
        (percent.coerceIn(0, 85) * 255 / 100), 2, 4, 10
    )

    private fun applySavedWallpaper() {
        val type = prefs.getString("wallpaper_type", "turbine") ?: "turbine"
        val uri = prefs.getString("wallpaper_uri", null)
        val picture = wallpaperDrawable(type, uri)
        if (picture != null) {
            root.background = LayerDrawable(arrayOf(
                picture,
                ColorDrawable(dimColor(prefs.getInt("wallpaper_dim", 42)))
            ))
        } else {
            root.setBackgroundColor(dark)
        }
    }

    private fun showWallpaperScreen() {
        val screen = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 8, 12, 8)
            setBackgroundColor(Color.rgb(5, 7, 13))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(label("ATMOSPHERIC WALLPAPER", 20f, red, true), LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(label("SELECT  •  PREVIEW  •  APPLY", 10f, Color.LTGRAY, true))
        screen.addView(header)

        val body = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val preview = FrameLayout(this).apply {
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.rgb(10, 12, 18)); cornerRadius = 15f; setStroke(2, red)
            }
            clipToOutline = true
        }
        val previewImage = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setImageDrawable(wallpaperDrawable(previewWallpaperType, previewWallpaperUri))
        }
        preview.addView(previewImage, FrameLayout.LayoutParams(-1, -1))
        val scrim = View(this).apply { setBackgroundColor(dimColor(previewWallpaperDim)) }
        preview.addView(scrim, FrameLayout.LayoutParams(-1, -1))
        val previewCaption = TextView(this).apply {
            text = when (previewWallpaperType) {
                "gallery" -> "CUSTOM GALLERY WALLPAPER"
                "turbine" -> "REDMAGIC TURBINE CORE"
                else -> "REDMAGIC CYBER WALLPAPER"
            }
            textSize = 13f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
            setPadding(12, 8, 12, 8)
            setBackgroundColor(Color.argb(125, 0, 0, 0))
        }
        preview.addView(previewCaption, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        body.addView(preview, LinearLayout.LayoutParams(0, -1, 1f).apply { setMargins(0, 5, 10, 5) })

        val rail = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(5, 2, 2, 2)
        }
        rail.addView(label("BUILT-IN THEMES", 11f, Color.LTGRAY, true))
        val scroll = ScrollView(this)
        val choices = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val themes = listOf(
            Triple("turbine", "REDMAGIC TURBINE", R.drawable.wallpaper_redmagic_turbine),
            Triple("crimson", "CRIMSON CIRCUIT", R.drawable.wallpaper_crimson_circuit),
            Triple("blue", "BLUE VELOCITY", R.drawable.wallpaper_blue_velocity),
            Triple("violet", "VIOLET GRID", R.drawable.wallpaper_violet_grid),
            Triple("obsidian", "OBSIDIAN SHARDS", R.drawable.wallpaper_obsidian_shards),
            Triple("cyan", "CYAN PULSE", R.drawable.wallpaper_cyan_pulse)
        )
        themes.forEach { (id, title, imageRes) ->
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(5, 4, 5, 4)
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(Color.rgb(19, 22, 31)); cornerRadius = 9f
                    setStroke(if (previewWallpaperType == id) 2 else 1,
                        if (previewWallpaperType == id) red else Color.rgb(55, 59, 72))
                }
            }
            val thumb = ImageView(this).apply {
                setImageResource(imageRes); scaleType = ImageView.ScaleType.CENTER_CROP
            }
            item.addView(thumb, LinearLayout.LayoutParams(58, 42))
            item.addView(label(title, 11f, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
            item.setOnClickListener {
                previewWallpaperType = id
                previewWallpaperUri = null
                showWallpaperScreen()
            }
            choices.addView(item, LinearLayout.LayoutParams(-1, 52).apply { setMargins(0, 2, 0, 3) })
        }
        if (previewWallpaperType == "gallery") {
            val custom = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(5, 4, 5, 4)
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(Color.rgb(19, 22, 31)); cornerRadius = 9f; setStroke(2, red)
                }
            }
            custom.addView(label("✓", 20f, red, true))
            custom.addView(label("CUSTOM PHOTO", 11f, Color.WHITE, true))
            choices.addView(custom, LinearLayout.LayoutParams(-1, 48).apply { setMargins(0, 2, 0, 3) })
        }
        scroll.addView(choices)
        rail.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        rail.addView(button("＋  GALLERY") { chooseWallpaperFromGallery() }, LinearLayout.LayoutParams(-1, 46))
        body.addView(rail, LinearLayout.LayoutParams(178, -1))
        screen.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 3, 0, 0)
        }
        val dimValue = label("DIM  ${previewWallpaperDim}%", 11f, Color.LTGRAY, true)
        controls.addView(dimValue)
        val dimSlider = SeekBar(this).apply {
            max = 85; progress = previewWallpaperDim
            progressTintList = android.content.res.ColorStateList.valueOf(red)
            thumbTintList = android.content.res.ColorStateList.valueOf(red)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    previewWallpaperDim = progress
                    dimValue.text = "DIM  ${progress}%"
                    scrim.setBackgroundColor(dimColor(progress))
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        controls.addView(dimSlider, LinearLayout.LayoutParams(0, 42, 1f))
        controls.addView(button("CANCEL") { showHub() })
        controls.addView(button("APPLY") {
            val editor = prefs.edit()
                .putString("wallpaper_type", previewWallpaperType)
                .putInt("wallpaper_dim", previewWallpaperDim)
            if (previewWallpaperType == "gallery" && previewWallpaperUri != null) {
                editor.putString("wallpaper_uri", previewWallpaperUri)
            } else {
                editor.remove("wallpaper_uri")
            }
            editor.apply()
            showHub()
            Toast.makeText(this, "Wallpaper applied to Game Space", Toast.LENGTH_SHORT).show()
        })
        screen.addView(controls)
        setContentView(screen)
    }

    private fun chooseWallpaperFromGallery() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "image/*"
            addCategory(Intent.CATEGORY_OPENABLE)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, REQUEST_WALLPAPER)
    }

    private fun scanApps() {
        val pm = packageManager
        installedApps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            .filter { it.packageName != packageName && pm.getLaunchIntentForPackage(it.packageName) != null }
            .sortedBy { pm.getApplicationLabel(it).toString().lowercase() }
        renderApps("")
    }

    private fun renderApps(query: String) {
        if (!::appList.isInitialized) return
        appList.removeAllViews()
        val pm = packageManager
        val pinned = prefs.getStringSet("pinned_apps", emptySet()) ?: emptySet()
        installedApps.filter { pm.getApplicationLabel(it).toString().contains(query, true) }
            .forEach { info ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                    setPadding(7, 2, 7, 2)
                    background = android.graphics.drawable.GradientDrawable().apply {
                        setColor(Color.rgb(19, 22, 31)); cornerRadius = 10f; setStroke(1, Color.rgb(65, 28, 40))
                    }
                }
                val icon = ImageView(this).apply { setImageDrawable(pm.getApplicationIcon(info)) }
                row.addView(icon, LinearLayout.LayoutParams(38, 38))
                val name = pm.getApplicationLabel(info).toString()
                row.addView(label(name + if (pinned.contains(info.packageName)) "  ★" else "", 13f, Color.WHITE, true),
                    LinearLayout.LayoutParams(0, -2, 1f))
                row.addView(button(if (pinned.contains(info.packageName)) "PINNED" else "PIN") {
                    val updated = (prefs.getStringSet("pinned_apps", emptySet()) ?: emptySet()).toMutableSet()
                    if (updated.contains(info.packageName)) updated.remove(info.packageName) else updated.add(info.packageName)
                    prefs.edit().putStringSet("pinned_apps", updated).apply(); renderApps(search.text.toString())
                })
                row.addView(button("LAUNCH") { launchPackage(info.packageName) })
                appList.addView(row, LinearLayout.LayoutParams(-1, 48).apply { setMargins(0, 2, 0, 2) })
            }
    }

    private fun launchPackage(pkg: String) {
        val launch = packageManager.getLaunchIntentForPackage(pkg)
        if (launch == null) Toast.makeText(this, "App does not provide a launch screen", Toast.LENGTH_SHORT).show()
        else try { launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(launch) }
        catch (e: Exception) { Toast.makeText(this, "Could not launch app: ${e.message}", Toast.LENGTH_LONG).show() }
    }

    private fun showAppPicker() {
        val pm = packageManager
        val choices = installedApps
        val names = choices.map { pm.getApplicationLabel(it).toString() }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Choose an app to pin")
            .setItems(names) { _, which ->
                val pkg = choices[which].packageName
                val updated = (prefs.getStringSet("pinned_apps", emptySet()) ?: emptySet()).toMutableSet()
                updated.add(pkg); prefs.edit().putStringSet("pinned_apps", updated).apply()
                Toast.makeText(this, "Pinned ${names[which]}", Toast.LENGTH_SHORT).show(); renderApps(search.text.toString())
            }.setNegativeButton("Cancel", null).show()
    }

    private fun setMode(mode: String) {
        selectedMode = mode
        prefs.edit().putString("mode", mode).apply()
        val explanation = when (mode) {
            "ECO" -> "Software profile selected: reduced visual activity in this companion app. It cannot force the phone CPU/GPU to downclock."
            "BALANCE" -> "Balanced companion-app profile selected. Samsung controls device scheduling and thermal limits."
            "RISE" -> "Performance-style companion-app profile selected. Android does not grant this app CPU/GPU overclock access."
            else -> "Diablo-style visual profile selected. This is not REDMAGIC Diablo hardware mode and does not change clock or voltage limits."
        }
        Toast.makeText(this, explanation, Toast.LENGTH_LONG).show()
        showHub()
    }

    private fun telemetryLine(): String {
        val battery = getSystemService(BATTERY_SERVICE) as android.os.BatteryManager
        val percent = battery.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val tempRaw = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        val temp = if (tempRaw >= 0) "${number.format(tempRaw / 10.0)}°C" else "N/A"
        val memory = ActivityManager.MemoryInfo()
        (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(memory)
        val ram = memory.availMem / (1024 * 1024)
        val rx = TrafficStats.getTotalRxBytes(); val tx = TrafficStats.getTotalTxBytes()
        val rxRate = if (lastRx >= 0 && rx >= lastRx) (rx - lastRx) / 1024 else 0
        val txRate = if (lastTx >= 0 && tx >= lastTx) (tx - lastTx) / 1024 else 0
        lastRx = rx; lastTx = tx
        return "BAT ${percent}%  •  BATTERY TEMP $temp  •  FREE RAM ${ram}MB  •  NET ↓${rxRate} ↑${txRate} KB/s  •  $selectedMode"
    }

    private fun chooseWallpaper() {
        previewWallpaperType = prefs.getString("wallpaper_type", "turbine") ?: "turbine"
        previewWallpaperUri = prefs.getString("wallpaper_uri", null)
        previewWallpaperDim = prefs.getInt("wallpaper_dim", 42).coerceIn(0, 85)
        showWallpaperScreen()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_WALLPAPER && resultCode == RESULT_OK) {
            data?.data?.let { uri ->
                try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
                previewWallpaperType = "gallery"
                previewWallpaperUri = uri.toString()
                showWallpaperScreen()
            }
        } else if (requestCode == REQUEST_WALLPAPER && resultCode != RESULT_OK) {
            showWallpaperScreen()
        } else if (requestCode == REQUEST_CAPTURE && resultCode == RESULT_OK && data != null) {
            val service = Intent(this, EnergyOverlayService::class.java).apply {
                action = EnergyOverlayService.ACTION_START_CAPTURE
                putExtra(EnergyOverlayService.EXTRA_RESULT_CODE, resultCode)
                putExtra(EnergyOverlayService.EXTRA_RESULT_DATA, data)
            }
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(service) else startService(service)
            Toast.makeText(this, "Screen FPS estimation started. Keep the capture notification active.", Toast.LENGTH_LONG).show()
        }
    }

    private fun enableOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:$packageName")))
            Toast.makeText(this, "Allow Display over other apps, then tap ENABLE ENERGY CUBE again.", Toast.LENGTH_LONG).show(); return
        }
        val service = Intent(this, EnergyOverlayService::class.java).apply { action = EnergyOverlayService.ACTION_SHOW_OVERLAY }
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(service) else startService(service)
        Toast.makeText(this, "Energy Cube edge handles enabled.", Toast.LENGTH_SHORT).show()
    }

    private fun requestFpsPermission() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Enable Energy Cube first and grant Display over other apps.", Toast.LENGTH_LONG).show(); enableOverlay(); return
        }
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mgr.createScreenCaptureIntent(), REQUEST_CAPTURE)
    }

    private fun showGuide() {
        AlertDialog.Builder(this).setTitle("ENERGY CUBE GESTURES & FPS")
            .setMessage("1. Enable Energy Cube and allow Display over other apps.\n2. Start Live Screen FPS and approve Android's screen-capture prompt.\n3. While inside a game, swipe inward from either edge once, then swipe inward again to open the booster.\n4. The FPS figure is estimated from changed frames captured from the actual display. Android does not expose another app's private GPU/game-engine FPS counter to normal apps; capture may be throttled and is limited by the A50's 60Hz display.")
            .setPositiveButton("OK", null).show()
    }

    private fun showSettings() {
        val options = arrayOf(
            "Auto profile when launching a game (preference only)",
            "Show edge swipe handles",
            "Keep brightness preference unchanged",
            "Touch guard reminder",
            "Notification display preference: Banner",
            "Auto reject calls preference (not system-enforced)"
        )
        val keys = arrayOf("auto_boost", "edge_swipe", "brightness_lock", "touch_guard", "banner", "reject_calls")
        val checked = BooleanArray(options.size) { prefs.getBoolean(keys[it], it == 1) }
        AlertDialog.Builder(this).setTitle("GAME SPACE SETTINGS")
            .setMultiChoiceItems(options, checked) { _, which, value -> prefs.edit().putBoolean(keys[which], value).apply() }
            .setPositiveButton("DONE", null).show()
    }

    private fun showPlugins() {
        val entries = arrayOf("Counter", "Stopwatch", "Card Draw Assist", "Controller / Gravity X", "Display / Cast settings", "Usage time for apps")
        AlertDialog.Builder(this).setTitle("GAME SPACE PLUGINS").setItems(entries) { _, which ->
            when (which) {
                0 -> counterPlugin()
                1 -> stopwatchPlugin()
                2 -> cardDrawPlugin()
                3 -> controllerPlugin()
                4 -> try { startActivity(Intent("android.settings.CAST_SETTINGS")) } catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
                5 -> usageInfo()
            }
        }.setNegativeButton("CLOSE", null).show()
    }

    private fun counterPlugin() {
        var count = 0
        val value = TextView(this).apply { text = "0"; textSize = 36f; gravity = Gravity.CENTER; setTextColor(red) }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(value) }
        val dialog = AlertDialog.Builder(this).setTitle("COUNTER").setView(box).setNegativeButton("CLOSE", null).create()
        box.addView(button("+1") { count++; value.text = count.toString() })
        box.addView(button("RESET") { count = 0; value.text = "0" })
        dialog.show()
    }

    private fun stopwatchPlugin() {
        val started = SystemClock.elapsedRealtime()
        val value = TextView(this).apply { setTextColor(Color.WHITE); textSize = 24f; gravity = Gravity.CENTER }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(value) }
        val dialog = AlertDialog.Builder(this).setTitle("STOPWATCH").setView(box).setPositiveButton("CLOSE", null).create()
        val tick = object : Runnable {
            override fun run() {
                if (!dialog.isShowing) return
                val elapsed = (SystemClock.elapsedRealtime() - started) / 1000
                value.text = String.format("%02d:%02d", elapsed / 60, elapsed % 60)
                value.postDelayed(this, 250)
            }
        }
        dialog.setOnShowListener { value.post(tick) }; dialog.show()
    }

    private fun cardDrawPlugin() {
        val cards = listOf("Knight", "Archer", "Giant", "Wizard", "Goblin", "Dragon", "Healer", "Ranger")
        AlertDialog.Builder(this).setTitle("CARD DRAW ASSIST").setMessage("Random pick: ${cards.random()}")
            .setPositiveButton("DRAW AGAIN") { _, _ -> cardDrawPlugin() }.setNegativeButton("CLOSE", null).show()
    }

    private fun controllerPlugin() {
        AlertDialog.Builder(this).setTitle("GRAVITY X / CONTROLLER")
            .setMessage("Connect a Bluetooth or USB gamepad. This screen can receive controller key events while focused; it cannot remap touches inside another app or emulate REDMAGIC's proprietary Gravity X system.")
            .setPositiveButton("OPEN CAST SETTINGS") { _, _ ->
                try { startActivity(Intent("android.settings.CAST_SETTINGS")) } catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
            }.setNegativeButton("CLOSE", null).show()
    }

    private fun usageInfo() {
        val usage = getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager
        val end = System.currentTimeMillis(); val start = end - 24L * 60 * 60 * 1000
        val list = usage.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, start, end)
        if (list.isNullOrEmpty()) {
            AlertDialog.Builder(this).setTitle("APP USAGE TIME").setMessage("Grant Usage access in Android Settings to read app usage totals.")
                .setPositiveButton("OPEN SETTINGS") { _, _ -> try { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) } catch (_: Exception) { } }
                .setNegativeButton("CLOSE", null).show()
        } else {
            val message = list.sortedByDescending { it.totalTimeInForeground }.take(12)
                .joinToString("\n") { "${it.packageName}: ${it.totalTimeInForeground / 60000} min" }
            AlertDialog.Builder(this).setTitle("APP USAGE (LAST 24H)").setMessage(message).setPositiveButton("OK", null).show()
        }
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN && event.keyCode >= KeyEvent.KEYCODE_BUTTON_A && event.keyCode <= KeyEvent.KEYCODE_BUTTON_MODE) {
            Toast.makeText(this, "Controller input: ${KeyEvent.keyCodeToString(event.keyCode)}", Toast.LENGTH_SHORT).show()
            return true
        }
        return super.dispatchKeyEvent(event)
    }
}
