package com.example.redmagicstyle

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.*
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.WindowManager
import android.widget.*
import android.graphics.drawable.GradientDrawable
import java.io.File
import java.util.ArrayDeque
import kotlin.math.abs

class EnergyOverlayService : Service() {
    companion object {
        const val ACTION_SHOW_OVERLAY = "com.example.redmagicstyle.SHOW_OVERLAY"
        const val ACTION_START_CAPTURE = "com.example.redmagicstyle.START_CAPTURE"
        const val EXTRA_RESULT_CODE = "projection_result_code"
        const val EXTRA_RESULT_DATA = "projection_result_data"
        private const val CHANNEL = "energy_cube_overlay"
        private const val NOTIFICATION_ID = 12
    }

    private lateinit var wm: WindowManager
    private val mainHandler = Handler(Looper.getMainLooper())
    private val handles = mutableListOf<TextView>()
    private var panel: LinearLayout? = null
    private var fpsText: TextView? = null
    private var infoBadge: TextView? = null
    private var pinned = false
    private var swipeCount = 0
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var captureThread: HandlerThread? = null
    private var captureHandler: Handler? = null
    @Volatile private var liveFps = 0
    @Volatile private var capturedFrameCount = 0L
    @Volatile private var captureActive = false

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, makeNotification(), 0)
        showHandles()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_START_CAPTURE) {
            val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
            val resultData = intent.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
            if (resultData != null && resultCode == Activity.RESULT_OK) startScreenCapture(resultCode, resultData)
        }
        return START_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "Energy Cube controls", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun makeNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        return builder.setContentTitle("Energy Cube active")
            .setContentText("Edge gestures and optional live screen FPS estimate are running")
            .setSmallIcon(android.R.drawable.ic_media_play).setOngoing(true).build()
    }

    private fun layoutParams(width: Int, height: Int, gravity: Int, x: Int = 0): WindowManager.LayoutParams =
        WindowManager.LayoutParams(width, height, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply { this.gravity = gravity; this.x = x }

    private fun showHandles() {
        if (handles.isNotEmpty()) return
        val left = makeHandle("‹")
        val right = makeHandle("›")
        handles.add(left); handles.add(right)
        wm.addView(left, layoutParams(dp(18), dp(106), Gravity.CENTER_VERTICAL or Gravity.LEFT))
        wm.addView(right, layoutParams(dp(18), dp(106), Gravity.CENTER_VERTICAL or Gravity.RIGHT))
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun makeHandle(glyph: String): TextView = TextView(this).apply {
        text = glyph; textSize = 23f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
        background = GradientDrawable().apply { setColor(Color.argb(220, 205, 20, 46)); cornerRadius = 12f }
        var downX = 0f
        setOnTouchListener { _, event ->
            when (event.action) {
                android.view.MotionEvent.ACTION_DOWN -> { downX = event.rawX; true }
                android.view.MotionEvent.ACTION_UP -> {
                    val delta = event.rawX - downX
                    val inward = if (glyph == "‹") delta > dp(16) else delta < -dp(16)
                    if (inward) {
                        swipeCount++
                        if (swipeCount >= 2) { swipeCount = 0; showPanel() }
                        else Toast.makeText(this@EnergyOverlayService, "Swipe inward one more time to open Energy Cube", Toast.LENGTH_SHORT).show()
                    }
                    true
                }
                else -> true
            }
        }
    }

    private fun showPanel() {
        if (panel != null) return
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(15), dp(12), dp(15), dp(12))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.argb(248, 25, 27, 38), Color.argb(245, 5, 6, 11))).apply {
                cornerRadius = dp(20).toFloat(); setStroke(dp(2), Color.rgb(255, 30, 50))
            }
        }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val logo = ImageView(this).apply { setImageResource(R.drawable.redmagic_emblem) }
        head.addView(logo, LinearLayout.LayoutParams(dp(38), dp(48)))
        head.addView(TextView(this).apply {
            text = "ENERGY CUBE"; textSize = 21f; letterSpacing = 0.1f; setTextColor(Color.rgb(255, 30, 50))
            typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
        })
        box.addView(head)
        val readings = TextView(this).apply {
            text = "CPU ${cpuClock()}  •  GPU N/A"; textSize = 13f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        }
        box.addView(readings)
        fpsText = TextView(this).apply {
            text = fpsLabel(); textSize = 16f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
        }
        box.addView(fpsText)
        box.addView(TextView(this).apply {
            text = "FPS is estimated from changed captured display frames"; textSize = 10f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER
        })

        val modes = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("ECO", "BALANCE", "RISE", "DIABLO").forEach { mode ->
            modes.addView(smallButton(mode) {
                getSharedPreferences("game_space", MODE_PRIVATE).edit().putString("mode", mode).apply()
                Toast.makeText(this@EnergyOverlayService, "$mode UI profile selected (no CPU/GPU overclock)", Toast.LENGTH_SHORT).show()
            }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { setMargins(dp(2), dp(3), dp(2), dp(3)) })
        }
        box.addView(modes)
        val tools = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tools.addView(smallButton(if (pinned) "UNPIN INFO" else "PIN INFO") { toggleInfoBadge() }, LinearLayout.LayoutParams(0, dp(42), 1f))
        tools.addView(smallButton("REFRESH CPU") { readings.text = "CPU ${cpuClock()}  •  GPU N/A" }, LinearLayout.LayoutParams(0, dp(42), 1f))
        tools.addView(smallButton("STOP FPS") { stopCapture() }, LinearLayout.LayoutParams(0, dp(42), 1f))
        tools.addView(smallButton("CLOSE") { removePanel() }, LinearLayout.LayoutParams(0, dp(42), 1f))
        box.addView(tools)
        panel = box
        wm.addView(box, layoutParams(dp(510), dp(285), Gravity.CENTER))
        updateUiRunnable.run()
    }

    private fun smallButton(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label; textSize = 10f; isAllCaps = false; setTextColor(Color.WHITE)
        background = GradientDrawable().apply { setColor(Color.rgb(38, 39, 52)); cornerRadius = dp(9).toFloat(); setStroke(dp(1), Color.rgb(255, 30, 50)) }
        setOnClickListener { action() }
    }

    private fun fpsLabel(): String = when {
        captureActive && capturedFrameCount == 0L -> "DISPLAY FPS: --  (waiting for display frames)"
        captureActive -> "DISPLAY FPS: $liveFps"
        capturedFrameCount > 0L -> "DISPLAY FPS: STOPPED"
        else -> "DISPLAY FPS: --  (start capture in hub)"
    }

    private val updateUiRunnable = object : Runnable {
        override fun run() {
            fpsText?.text = fpsLabel()
            infoBadge?.text = "${liveFps} FPS  •  ${batteryTemp()}"
            if (panel != null || infoBadge != null) mainHandler.postDelayed(this, 300)
        }
    }

    private fun toggleInfoBadge() {
        if (pinned) {
            infoBadge?.let { try { wm.removeView(it) } catch (_: Exception) { } }; infoBadge = null; pinned = false
        } else {
            val badge = TextView(this).apply {
                text = fpsLabel(); textSize = 12f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
                setPadding(dp(10), dp(7), dp(10), dp(7))
                background = GradientDrawable().apply { setColor(Color.argb(225, 12, 13, 20)); cornerRadius = dp(12).toFloat(); setStroke(dp(1), Color.rgb(255, 30, 50)) }
            }
            infoBadge = badge; pinned = true
            wm.addView(badge, layoutParams(dp(155), dp(40), Gravity.TOP or Gravity.RIGHT).apply { y = dp(85) })
        }
    }

    private fun removePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) { } }; panel = null; fpsText = null
    }

    private fun startScreenCapture(resultCode: Int, data: Intent) {
        if (projection != null) stopCapture()
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFICATION_ID, makeNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        try {
            projection = manager.getMediaProjection(resultCode, data)
        } catch (e: Exception) {
            Toast.makeText(this, "Screen capture could not start: ${e.message}", Toast.LENGTH_LONG).show(); return
        }
        if (projection == null) return
        captureActive = true
        captureThread = HandlerThread("EnergyCubeFrameSampler").also { it.start() }
        captureHandler = Handler(captureThread!!.looper)
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 3)
        val previous = IntArray(240)
        var hasPrevious = false
        val frameTimes = ArrayDeque<Long>()
        var lastUi = 0L
        imageReader!!.setOnImageAvailableListener({ reader ->
            val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val sample = sampleFrame(image)
                var changed = false
                if (hasPrevious) {
                    var changes = 0
                    for (i in sample.indices) if (abs(sample[i] - previous[i]) > 12) changes++
                    changed = changes >= 4
                }
                System.arraycopy(sample, 0, previous, 0, sample.size)
                hasPrevious = true
                val stamp = image.timestamp
                if (changed) {
                    frameTimes.addLast(stamp)
                    capturedFrameCount++
                }
                while (frameTimes.isNotEmpty() && stamp - frameTimes.peekFirst() > 1_000_000_000L) frameTimes.removeFirst()
                liveFps = frameTimes.size
                val now = SystemClock.elapsedRealtime()
                if (now - lastUi >= 250) { lastUi = now; mainHandler.post { fpsText?.text = fpsLabel() } }
            } catch (_: Exception) {
            } finally { image.close() }
        }, captureHandler)
        projection!!.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopCapture() }
        }, captureHandler)
        virtualDisplay = projection!!.createVirtualDisplay("EnergyCubeDisplayFPS", width, height,
            metrics.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader!!.surface, null, captureHandler)
        mainHandler.post { fpsText?.text = fpsLabel() }
    }

    private fun sampleFrame(image: Image): IntArray {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val rowStride = plane.rowStride
        val pixelStride = plane.pixelStride
        val result = IntArray(240)
        var index = 0
        // Sampling distributed points across the real display avoids allocating/copying whole frames.
        for (gy in 1..12) {
            val y = (gy * image.height / 13).coerceIn(0, image.height - 1)
            for (gx in 1..20) {
                val x = (gx * image.width / 21).coerceIn(0, image.width - 1)
                val offset = y * rowStride + x * pixelStride
                if (offset + 2 < buffer.limit()) {
                    val r = buffer.get(offset).toInt() and 0xff
                    val g = buffer.get(offset + 1).toInt() and 0xff
                    val b = buffer.get(offset + 2).toInt() and 0xff
                    result[index] = ((r shr 3) shl 10) or ((g shr 3) shl 5) or (b shr 3)
                }
                index++
            }
        }
        return result
    }

    private fun cpuClock(): String = try {
        val khz = File("/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq").readText().trim().toLong()
        "${khz / 1000} MHz"
    } catch (_: Exception) { "N/A" }

    private fun batteryTemp(): String = try {
        val battery = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val raw = battery?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        if (raw >= 0) "${raw / 10.0}°C" else "Temp N/A"
    } catch (_: Exception) { "Temp N/A" }

    private fun stopCapture() {
        try { virtualDisplay?.release() } catch (_: Exception) { }
        virtualDisplay = null
        try { imageReader?.close() } catch (_: Exception) { }
        imageReader = null
        val oldProjection = projection
        projection = null
        try { oldProjection?.stop() } catch (_: Exception) { }
        captureThread?.quitSafely(); captureThread = null; captureHandler = null
        captureActive = false
        liveFps = 0
        mainHandler.post { fpsText?.text = fpsLabel() }
    }

    override fun onDestroy() {
        removePanel()
        infoBadge?.let { try { wm.removeView(it) } catch (_: Exception) { } }
        handles.forEach { try { wm.removeView(it) } catch (_: Exception) { } }
        handles.clear()
        stopCapture()
        mainHandler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null
}
